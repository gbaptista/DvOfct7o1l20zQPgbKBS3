import{a as t}from"../chunks/entry.CVkj6Mtl.js";export{t as start};

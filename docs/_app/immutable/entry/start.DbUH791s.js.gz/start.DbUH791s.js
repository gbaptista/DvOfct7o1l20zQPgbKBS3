import{a as t}from"../chunks/entry.CgoL3P9B.js";export{t as start};

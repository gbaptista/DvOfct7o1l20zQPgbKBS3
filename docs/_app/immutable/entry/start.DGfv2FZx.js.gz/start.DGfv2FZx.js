import{a as t}from"../chunks/entry.htboiiY8.js";export{t as start};

import{a as t}from"../chunks/entry.D2yvMdyp.js";export{t as start};

import{a as t}from"../chunks/entry.OA_5pcrP.js";export{t as start};

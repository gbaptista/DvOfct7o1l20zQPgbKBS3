import{a as t}from"../chunks/entry.DqKQ0K3U.js";export{t as start};
